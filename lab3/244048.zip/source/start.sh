#!/bin/bash
python3 ./server.py
